/* state of upload for progress */
const uploadState = { uploading: false };

// prettier-ignore
const languages = {
  'c': 'c',
  'c++': 'cpp',
  'python': 'py',
  'java': 'java'
};
